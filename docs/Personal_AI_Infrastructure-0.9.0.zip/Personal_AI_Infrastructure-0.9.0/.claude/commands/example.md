You are helping the user with a task.

Analyze the following and provide:
1. A brief summary
2. Key insights
3. Recommended next steps

Content to analyze:

$ARGUMENTS
